const {test,expect} = require('@playwright/test');
const { LoginPage } = require('../pageobjects/Prod');

test('Update Order',async ({page})=>{

    const username="admin@honeysys.com";
    const password="superrdp@7890"
    const loginpage = new LoginPage(page);
    loginpage.goTo();
    loginpage.validLogin(username,password);
    loginpage.submit;
    //await page.goto("https://super-rdp.honebi.online/");
    //await page.locator("[name='username']").fill("admin@honeysys.com");
    //await page.locator("[name='p_sigassword']").fill("superrdp@7890");
    //await page.locator("#kt_loginnin_submit").click();
    //DashBoard Click
    const dashboard = page.locator("text=Dashboard");
    await dashboard.nth(1).click();
    //Stores Click
    await page.locator("text=Total Stores").click();
    //Store name based on row
    await page.locator("[row-id='2'] div a").click();
    //Search the product name
    await page.locator(".show-button-div").click();
    const dropDown = page.locator("select.inputBox").first();
    const productName = dropDown.selectOption("productNames");
    await page.locator("[name='filedValue']").first().fill("Asahi Kasei Zipper Bag Large 270 X 280mm");
    await page.locator(".table-search-main-container button").click();
    //Click on product name
    const clickOnProduct = page.locator(".text-ellipsis-normal");
    await clickOnProduct.nth(0).click();
    await page.locator("#accordion__heading-3").click();
    await page.locator(".action-division").click();
    await page.screenshot({ path: 'fullpage-screenshot.png', fullPage: true });
    const cancel = page.locator("div .side_margin button");
    await cancel.nth(1).click();
    //goto orders
    const order = page.locator("text=Orders");
    await order.nth(0).click();
    await order.nth(1).click();
    await page.locator("text=ORD221089987").click();
    //edit order status label
    await page.locator("text=Order Status").click();
    const orderDropdown = page.locator(".modal-popup-form_defaultSelectTag__Ca-zk");
    await orderDropdown.selectOption("Accepted");
    await page.locator(".order-product-list-drawer_footerBtnChild__9M4nX button").click();
    //Update the order
    await page.locator(".dark_green").click();
    const message = page.locator(".MuiAlert-message");
    await expect(message).toContainText("Updated Successfully");

    //take the screenshot of reserve quatity    

})
