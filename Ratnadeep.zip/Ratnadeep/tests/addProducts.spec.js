const { test, expect } = require('@playwright/test');
const { HomePage } = require('../pageobjects/Homapage');
const { CartPage } = require('../pageobjects/CartPage');

test('Add Products in Cart', async ({ page }) => {
    const homePage = new HomePage(page);
    const cartPage = new CartPage(page);
    await homePage.goto();
    //await homePage.isHomeIconVisible();
    await homePage.addProductToCart(0);
    await homePage.continueShopping();
    await homePage.addProductToCart(1);
    await homePage.viewCart();
    await cartPage.verifyProductInCart(1);
    await cartPage.verifyProductInCart(2);
    await cartPage.verifyCartDetails();
});