const {test, expect} = require("@playwright/test");
const { HomePage } = require('..pageobjects/HomePage');

test('Verify Scroll Up &Down functionality',async({page}) => {
    
    const homePage = new HomePage(page);

    await homePage.goto();

    await homePage.isHomeIconVisible();

    await page.locator(".single-widget").scrollIntoViewIfNeeded();

    await page.locator(".single-widget").isVisible();

    await page.locator('.col-sm-12').scrollIntoViewIfNeeded();

    let titles = await page.locator("text='Full-Fledged practice website for Automation Engineers'");

    await titles.nth(0).isVisible();
    





})