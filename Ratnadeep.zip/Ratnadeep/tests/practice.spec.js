const {test,expect} = require('@playwright/test')

test('Focus the element ', async ({page})=>{

    await page.goto("https://super-pkt.honebi.online/");
    const hover =  await page.locator("[name='username']");
    await hover.focus();

})

test('Enter Character by Character with a Delay in a TextField ', async ({page})=>{

    await page.goto("https://super-pkt.honebi.online/");
    const hover =  await page.locator("[name='username']");
    await hover.focus();
    await hover.pressSequentially("admin@honeysy",{delay:500});
    await page.waitForTimeout(3000);

})

test('Right Click',async ({page})=>{


    await page.goto("http://swisnl.github.io/jQuery-contextMenu/demo.html");
    let button = await page.locator("//span[@class='context-menu-one btn btn-neutral']");

    await button.click({button:'right'});

})

test('Drag & Drop', async ({page})=>{


    await page.goto("http://dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");

    const source = await page.locator("//div[@id='box3']");
    const destination = await page.locator("//div[@id='box103']");

    //await source.dragTo(destination);

    await source.hover();

    await page.mouse.down();

    await destination.hover();

    await page.mouse.up();
})

test('Handling Frames', async ({page})=>{

    await page.goto("https://ui.vision/demo/webtest/frames/");

    const frame3 = await page.frame({url:'https://ui.vision/demo/webtest/frames/frame_3.html'});
    //await frame3.locator("[name='mytext3']").fill('Welcome');

    const childFrames = await frame3.childFrames();
    await childFrames[0].locator("text='Hi, I am the UI.Vision IDE'").click();
})

test.only('Double Click', async ({page})=>{

    await page.goto("https://testautomationpractice.blogspot.com/");

    let button = await page.locator("text='Copy Text'");

    button.dblclick();

    let tet = await page.locator("#field2");
    await expect(tet).toHaveValue("Hello World!");
    await page.waitForTimeout(5000);
})

    
