const { test, expect, request } = require("@playwright/test");

const loginPayLoad = {
  clientId: "2508190884",
  secret: "9b395a79-b30a-4f3a-abb4-22b76d62ee07",
  loginId: "admin@honeysys.com",
  password: "superrdp@7890",
};

let access;
let userDetails;
let permissions;
let userData;

test.beforeAll(async () => {
  const apiContext = await request.newContext();
  const loginResponse = await apiContext.post(
    "https://apigw-rdp.honebi.online/admin-gateway/auth/access-token?userType=Admin",
    {
      data: loginPayLoad,
    }
  );

  const loginResponseText = await loginResponse.text();
  expect(loginResponse.ok()).toBeTruthy();
  const loginResponseJson = await loginResponse.json();
  permissions = await apiContext.get(
    "https://apigw-rdp.honebi.online/admin-gateway/permissions",
    {
      headers: {
        Authorization: loginResponseJson.data.access_token,
        clientId: loginPayLoad.clientId,
        secret: loginPayLoad.secret,
      },
    }
  );
  permissions = await permissions.json();
  permissions = JSON.stringify(permissions.data);
  access = loginResponseJson.data.access_token;
  userDetails = JSON.stringify(loginResponseJson.data);
  userData = loginResponseJson.data;
  await apiContext.dispose();
});

test("Create Picker", async ({ page }) => {
  await page.addInitScript((value) => {
    window.sessionStorage.setItem("token", value);
  }, access);

  await page.addInitScript((value) => {
    window.localStorage.setItem("userDetails", value);
  }, userDetails);

  await page.addInitScript((value) => {
    window.localStorage.setItem("permission", value);
  }, permissions);

  await page.addInitScript((value) => {
    window.localStorage.setItem("userData", value);
  }, userData);

  await page.goto("https://super-rdp.honebi.online/dashboard");
  await page.locator("text=Masters").click();
  await page.locator("text=Pickers").click();
  await page.locator("button.pull-right").click();

  const stores = page.locator(".MuiAutocomplete-endAdornment");
  await stores.nth(0).click();
  await page.locator("text=Ratnadeep Siddipet").click();

  await page.locator("[name='pickerName']").fill("Dheeraj");
  await page.locator("[name='email']").fill("dheer@gmail.com");

  const radio = page.locator(".MuiFormControlLabel-root");
  await radio.nth(0).click();

  await page.locator("[name='mobile']").fill("9029384891");
  await page.locator("[name='password']").fill("welcome");

  await stores.nth(1).click();
  const option = page.locator(".MuiAutocomplete-option");
  await option.nth(0).click();

  await page.locator("button.dark_green").last().click();
});
