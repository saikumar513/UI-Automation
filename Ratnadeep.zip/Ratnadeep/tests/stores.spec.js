const {test, expect} = require('@playwright/test')

test('Login The Super Admin',async ({browser})=>
    {
        const context = await browser.newContext();
        const page = await context.newPage();
        await page.goto("https://rahulshettyacademy.com/loginpagePractise/");
        await page.locator("#username").fill("rahulshetty");
        await page.locator("#password").fill("learning");
        await page.locator("#signInBtn").click();
        console.log(await page.locator("[style*='block']").textContent());
        await expect(page.locator("[style*='block']")).toContainText('f');

        
    });
test('Login The E-commerce ',async ({page})=>
    {
        await page.goto("https://store-rdp.honebi.online/");
        console.log(await page.title());
        await expect(page).toHaveTitle("Store Admin");
    });
test.only('Create The Store', async({page})=>{

    await page.goto("https://super-rdp.honebi.online/");
    await page.locator("[name='username']").fill("admin@honeysys.com");
    await page.locator("[name='password']").fill("superrdp@7890");
    await page.locator("#kt_login_signin_submit").click();
    await page.locator("text=Stores").click();
    await page.locator("text='Store Creation'").click();
    //await page.locator("text='Store Creation'").click();
    await page.locator("text='Create Stores'").click();
    await page.locator("[name='storeName']").fill("Ratnadeep T");
    const dorp = page.locator(".MuiSvgIcon-root");
    await dorp.nth(1).click();
    await page.locator("text='Supermarket'").click();
    const business = await page.locator(".MuiAutocomplete-endAdornment");
    await business.nth(1).click();
    await page.locator("text='Ameerpet Belt'").click();
    await page.locator("[name='mobile']").fill("8193842421");
    await page.locator("[name='email']").first().fill("sai9@gmail.com");
    //await email.nth(1).fill("sai9@gmail.com");
    await page.locator("[name='addressName']").fill("Ratnadeep");
    await page.locator("[name='buildingName']").fill("RDP");
    await page.locator("[name='flatNo']").fill("34");
    await page.locator("[name='address1']").fill("Ratnadeep t");
    await business.nth(2).click();
    await page.locator("text='Karnataka'").click();
    await business.nth(4).click();
    await page.locator("text='Bengaluru'").click();
    await business.nth(3).click();
    await page.locator("text='Indiranagar'").click();
    await page.locator("[name='pincode']").fill("560038");
    await page.locator("[name='latitude']").fill("12.978346");
    await page.locator("[name='longitude']").fill("77.640787");
    await page.locator("[name='name']").fill("Niranjan");
    await page.locator("[name='designation']").fill("Manager");
    await page.locator("[name='email']").last().fill("sai9@gmail.com");
    await page.locator("[name='mobileNumber']").fill("9329499139");
    await page.locator("text='Add'").click();
    const submit = page.locator("text=Submit");
    await submit.last().click();
    const message = await page.locator(".MuiAlert-message");
    await expect(message).toContainText("Save Successfully");
    
    })

    test('Child Windows Handling',async ({browser})=>
{

    const context = await browser.newContext();
    const page = await context.newPage();
    await page.goto("https://rahulshettyacademy.com/loginpagePractise/");
    const name = page.locator(" #username");
    const documentLink = page.locator("[href*='documents-request']");

    const [newPage]=await Promise.all(
        [
            context.waitForEvent('page'),
            documentLink.click(),
        ])

       const text = await newPage.locator(".red").textContent();
       console.log(text);
      const arrayTest = text.split('@');
      const domain = arrayTest[1].split(" ")[0];
      console.log(domain);
    
      await page.locator("#username").fill(domain);
      await page.pause();
      console.log(await page.locator("#username").textContent());
      
       


})