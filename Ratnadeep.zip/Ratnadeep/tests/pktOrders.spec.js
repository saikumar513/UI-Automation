const { test, expect, request } = require('@playwright/test');

const loginPayLoad = {
    clientId: "2508190884",
    secret: "9b395a79-b30a-4f3a-abb4-22b76d62ee07",
    loginId: "admin@honeysys.com",
    password: "super@789",
  };
  
  let access;
  let userDetails;
  let permissions;
  let userData;
  

const orderPayLoad = {
  storeId: "62df787e6c6e1169d7465ef6",
  customerId: "65c365e277eaf5f124b7997d",
  orderProductCount: 0,
  deliveryInstructions: [],
  deliveryDetails: {
      deliveryDate: "03 Jun 2024",
      deliveryType: "Normal",
      slotIndex: 5,
      startTime: "18:00",
      endTime: "19:30"
  },
  productOffers: {},
  customerCode: "CUS22170406",
  customerType: "0",
  firstName: "sai",
  mobileNumber: "8125565513",
  storeName: "Ratnadeep Kondapur1",
  orderProduct: [
      {
          productId: "63160304f83d99dcd297a666",
          source: "orderProduct",
          productVariantIndex: "0",
          quantity: 1,
          price: 1119,
          discount: 269,
          discountType: "1"
      }
  ],
  shippingAddress: {
      name: "sai",
      mobile: "8125565513",
      addressId: 1707307178208,
      addressName: "Hotel",
      flatNo: "90",
      addressType: "billingAddress",
      alternateMobile: "",
      email: "",
      buildingName: "Kji",
      address1: "Masjid Banda Road",
      address2: "F87W+R94, 192, Masjid Banda Rd, Masjid Banda, Camelot Layout, Kondapur, Telangana 500084, India\n",
      pincode: "500084",
      state: "Telangana",
      city: "Kondapur",
      stateId: "6236a9358f0ef3f1d95b75b1",
      cityId: "6236a9488f0ef3f1d95b75b2",
      localityId: "630c9b54241edde48d3c3809",
      latitude: "17.464359",
      longitude: "78.34583"
  },
  billingAddress: {
      name: "sai",
      mobile: "8125565513",
      addressId: 1707307178208,
      addressName: "Hotel",
      flatNo: "90",
      addressType: "billingAddress",
      alternateMobile: "",
      email: "",
      buildingName: "Kji",
      address1: "Masjid Banda Road",
      address2: "F87W+R94, 192, Masjid Banda Rd, Masjid Banda, Camelot Layout, Kondapur, Telangana 500084, India\n",
      pincode: "500084",
      state: "Telangana",
      city: "Kondapur",
      stateId: "6236a9358f0ef3f1d95b75b1",
      cityId: "6236a9488f0ef3f1d95b75b2",
      localityId: "630c9b54241edde48d3c3809",
      latitude: "17.464359",
      longitude: "78.34583"
  },
  contactDetails: {
      name: "sai",
      mobile: "8125565513"
  },
  paymentMethod: "Pay on Delivery",
  deliveryCharge: "0.00",
  finalAmount: "850.00",
  minimumOrderAmount: true,
  appliedLoyaltyPoints: true,
  orderComments: "",
  promoCode: "",
  promoCodesDiscount: "",
  deletedOrderProduct: [],
  appliedPromoCode: false,
  deliveryTypes: "HOME_DELIVERY"
}

test.beforeAll(async () => {
    const apiContext = await request.newContext();
    const loginResponse = await apiContext.post(
      "https://apigw-rdp.honebi.online/admin-gateway/auth/access-token?userType=Admin",
      {
        data: loginPayLoad,
      }
    );
  
    const loginResponseText = await loginResponse.text();
    expect(loginResponse.ok()).toBeTruthy();
    const loginResponseJson = await loginResponse.json();
    permissions = await apiContext.get(
      "https://apigw-rdp.honebi.online/admin-gateway/permissions",
      {
        headers: {
          Authorization: loginResponseJson.data.access_token,
          clientId: loginPayLoad.clientId,
          secret: loginPayLoad.secret,
        },
      }
    );
    permissions = await permissions.json();
    permissions = JSON.stringify(permissions.data);
    access = loginResponseJson.data.access_token;
    userDetails = JSON.stringify(loginResponseJson.data);
    userData = loginResponseJson.data;
    await apiContext.dispose();
  });

  test('Create Order', async ({ page }) => {
  await page.addInitScript((value) => {
    window.sessionStorage.setItem("token", value);
  }, access);

  await page.addInitScript((value) => {
    window.localStorage.setItem("userDetails", value);
  }, userDetails);

  await page.addInitScript((value) => {
    window.localStorage.setItem("permission", value);
  }, permissions);

  await page.addInitScript((value) => {
    window.localStorage.setItem("userData", value);
  }, userData);
  
  const apiContext = await request.newContext();
  
  const orderResponse = await apiContext.post("https://apigw-rdp.honebi.online/admin-gateway/stores/62df787e6c6e1169d7465ef6/customers/65c365e277eaf5f124b7997d/orders", 
    { // added await
    data: orderPayLoad,
    
    headers: {
      Clientid: '2508190884',
      Secret: '9b395a79-b30a-4f3a-abb4-22b76d62ee07',
      Authorization:access // corrected Authorization usage
    }
    
});
  await page.goto("https://super-pkt.honebi.online/dashboard");// corrected URL if needed
//   const order = page.locator("text=Orders");
//   await order.nth(0).click();
//   await order.nth(1).click();;
//   await page.locator(".tabs_header").click();
  expect(orderResponse.ok()).toBeTruthy();
  const orderResponseJson = await orderResponse.json();
  console.log({orderResponseJson});
});