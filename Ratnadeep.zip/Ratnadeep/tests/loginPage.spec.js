const { test} = require('@playwright/test');
const { HomePage } = require('../pageobjects/Homapage');
const { LoginPage } = require('../pageobjects/LoginPage');

test('Login Page', async ({ page }) => {
    const homePage = new HomePage(page);
    const loginPage = new LoginPage(page);

   
    await homePage.goto();
    await homePage.clickLogin();  
    await loginPage.login('kiran13@gmail.com', 'Swathi@1');
    await loginPage.loginButton();
   

    
});