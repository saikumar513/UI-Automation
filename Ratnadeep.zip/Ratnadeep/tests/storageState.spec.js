const {test, expect} = require('@playwright/test')
let webContext;

test.beforeAll(async ({browser})=>{

    const context = await browser.newContext();
    const page = await context.newPage();
    await page.goto("https://super-rdclick.honebi.online/");
    await page.getByPlaceholder("Enter your login ID").fill("admin@honeysys.com");
    await page.getByPlaceholder("Enter your password").fill("super@789");
    await page.locator("#kt_login_signin_submit").click();
    await context.storageState({path: 'state.json'});
    webContext = await browser.newContext({storageState: 'state.json'});

})

test('Business Unit', async ()=>{

    const page = await webContext.newPage();
    await page.goto("https://super-rdclick.honebi.online/business-unit");
    await page.locator("text=Business Unit").click();
})

test('Shipment', async()=>{

    const page = await webContext.newPage();
    await page.goto("https://super-rdclick.honebi.online/ready-for-delivery");
    await page.locator("text=Shipment").click();
})