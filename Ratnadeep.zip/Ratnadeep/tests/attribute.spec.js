const {test} =require('@playwright/test')

test('Create Attribute', async ({page})=>{

    await page.goto("https://super-pkt.honebi.online/");
    await page.locator("[name='username']").fill("admin@honeysys.com");
    await page.locator("[name='password']").fill("super@789");
    await page.locator("#kt_login_signin_submit").click();
    await page.locator("text='Products'").click();
    //await page.locator("[title='Product Attribute']").click();
    await page.getByRole("button",{name: 'Product Attribute'}).click();
    await page.getByRole("")
    const cpa = page.locator("text='Create Product Attribute'");
    await cpa.first().click();
    await page.locator("[name='fieldType']").click();
    await page.locator("text='Characters'").click();
    await page.locator("[name='fieldLabel']").fill("test");
    await page.locator("[name='dataType']").click();
    const dtypes = page.locator("p.field-scratch_itemLabel__COnzx");
    await dtypes.first();
    await page.locator("[name='noOfCharacters']").fill("20");

});