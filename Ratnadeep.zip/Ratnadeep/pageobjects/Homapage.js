const {expect} = require('@playwright/test');
class HomePage {
    constructor(page) {
        this.page = page;
        this.loginButton = page.locator('.fa-lock');
        this.travelCard = page.locator('.card_travel');
        this.cartLink = page.locator('text="Cart"');
        this.addToCartButtons = page.locator('.add-to-cart');
        this.continueShoppingButton = page.locator('text="Continue Shopping"');
        this.viewCartButton = page.locator('text="View Cart"');
    }

    async goto() {
        await this.page.goto('https://automationexercise.com/');
    }

    async clickLogin() {
        await this.loginButton.click();
    }

    async clickTravelCard() {
        await this.travelCard.click();
    }

    // async isHomeIconVisible() {
    //     await expect(this.homeIcon).toBeVisible('.fa-home');
    // }

    async navigateToCart() {
        await this.cartLink.click();
    }

    async addProductToCart(index) {
        await this.addToCartButtons.nth(index).click();
    }
    
    async continueShopping() {
        await this.continueShoppingButton.click();
    }

    async viewCart() {
        await this.viewCartButton.click();
    }
}

module.exports = { HomePage };