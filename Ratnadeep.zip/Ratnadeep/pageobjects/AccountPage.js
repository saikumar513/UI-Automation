class AccountPage {
    constructor(page) {
        this.page = page;
        this.accountCreatedMessage = page.locator('text="Account Created!"');
        this.continueButton = page.locator('text="Continue"');
        this.usernameText = page.locator('text="saigoli7"');
        this.deleteAccountButton = page.locator('.fa-trash-o');
        this.accountDeletedMessage = page.locator('text="Account Deleted!"');
    }

    async verifyAccountCreated() {
        await this.accountCreatedMessage.isVisible();
        await this.continueButton.click();
    }

    async verifyAccountDeleted() {
        await this.accountDeletedMessage.isVisible();
        await this.continueButton.click();
    }

    async deleteAccount() {
        await this.deleteAccountButton.click();
    }
}

module.exports = { AccountPage };