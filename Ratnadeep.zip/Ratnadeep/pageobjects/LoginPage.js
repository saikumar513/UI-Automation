class LoginPage {
    constructor(page) {
        this.page = page;
        this.emailInput = page.locator('[name="email"]');
        this.passwordInput = page.locator('[placeholder="Password"]');
        this.loginButton = page.locator('text="Login"');
    }

    async login(email, password) {
        await this.emailInput.nth(0).fill(email);
        await this.passwordInput.fill(password);
        await this.loginButton.click();
    }
}

module.exports = { LoginPage };