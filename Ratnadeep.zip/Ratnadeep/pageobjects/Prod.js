class LoginPage {
    constructor(page)
    {
      this.page = page;
      this.userName = page.locator("[name='username']");
      this.password = page.locator("[name='password']");
      this.submit = page.locator("#kt_login_signin_submit");
    }

    async goTo()
    {
      await this.page.goto("https://super-rdp.honebi.online/");
    }
  
    async validLogin(admin, password1)
    {
      await this.userName.fill(admin);
      await this.password.fill(password1);
      await this.submit.click();
    }
  }
 
  module.exports = { LoginPage };