class SignupPage {
    constructor(page) {
        this.page = page;
        this.nameInput = page.locator('[placeholder="Name"]');
        this.emailInput = page.locator('[name="email"]');
        this.signupButton = page.locator('text="Signup"');
        this.genderRadio = page.locator('#id_gender1');
        this.passwordInput = page.locator('#password');
        this.daysDropdown = page.locator('[name="days"]');
        this.monthsDropdown = page.locator('[name="months"]');
        this.yearDropDown = page.locator("[name='years']");
        this.newsletterCheckbox = page.locator('#newsletter');
        this.optinCheckbox = page.locator('#optin');
        this.firstNameInput = page.locator('#first_name');
        this.lastNameInput = page.locator('#last_name');
        this.companyInput = page.locator('#company');
        this.address1Input = page.locator('#address1');
        this.address2Input = page.locator('#address2');
        this.countryDropdown = page.locator('#country');
        this.stateInput = page.locator('#state');
        this.cityInput = page.locator('#city');
        this.zipcodeInput = page.locator('#zipcode');
        this.mobileNumberInput = page.locator('#mobile_number');
        this.createAccountButton = page.locator('button:has-text("Create Account")');
    }

    async fillSignupForm() {
        await this.nameInput.fill('saigoli7');
        await this.emailInput.nth(1).fill('saikumar7@gmail.com');
        await this.signupButton.click();
        await this.genderRadio.click();
        await this.passwordInput.fill('Swathi@1');
        await this.daysDropdown.click();
        await this.daysDropdown.selectOption({ label: '12' });
        await this.monthsDropdown.selectOption('August');
        await this.yearDropDown.selectOption('1993');
        await this.newsletterCheckbox.click();
        await this.optinCheckbox.click();
        await this.firstNameInput.fill('Sai');
        await this.lastNameInput.fill('Goli');
        await this.companyInput.fill('Honeysys It Services');
        await this.address1Input.fill('JSA Towers, 204, Paramahansa Yogananda Rd, Indira Nagar');
        await this.address2Input.fill('Bangalore');
        await this.countryDropdown.selectOption('India');
        await this.stateInput.fill('Karnataka');
        await this.cityInput.fill('Bengaluru');
        await this.zipcodeInput.fill('560038');
        await this.mobileNumberInput.fill('8125565513');
        await this.createAccountButton.click();
    }
}

module.exports = { SignupPage };