const {test} = require('@playwright/test')

test('Focus the element ', async ({page})=>{

    await page.goto("https://super-pkt.honebi.online/");
    const hover =  await page.locator("[name='username']");
    await hover.focus();

})

test.only('Enter Character by Character with a Delay in a TextField ', async ({page})=>{

    await page.goto("https://super-pkt.honebi.online/");
    const hover =  await page.locator("[name='username']");
    await hover.focus();
    await hover.pressSequentially("admin@honeysy",{delay:500});
    await page.waitForTimeout(3000);

})