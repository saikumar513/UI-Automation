const { test, expect } = require('@playwright/test');
const { HomePage } = require('..pageobjects/HomePage');
const { ProductsPage } = require('..pageobjects/ProductsPage');

test('Search Product', async ({ page }) => {
    const homePage = new HomePage(page);
    const productsPage = new ProductsPage(page);

    
    await homePage.goto();

    await homePage.isHomeIconVisible();

    await homePage.clickTravelCard();

    await productsPage.verifyAllProductsHeader();

    await productsPage.searchProduct('Blue Top');

    await productsPage.verifySearchedProductsHeader();

    await page.screenshot({ path: 'search-product.png' });
});