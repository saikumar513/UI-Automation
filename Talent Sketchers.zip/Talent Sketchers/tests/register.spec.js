const { test, expect } = require('@playwright/test');
const { HomePage } = require('../pageobjects/Homapage');
const { SignupPage } = require('../pageobjects/SignupPage');
const { AccountPage } = require('../pageobjects/AccountPage');

test('Create New User', async ({ page }) => {
    const homePage = new HomePage(page);
    const signupPage = new SignupPage(page);
    const accountPage = new AccountPage(page);

    await homePage.goto();
    await homePage.clickLogin();

    await expect(page.locator('text="New User Signup!"')).toContainText('New User Signup!');

    await signupPage.fillSignupForm();

    await accountPage.verifyAccountCreated();

    await expect(accountPage.usernameText).toBeVisible();

    await accountPage.deleteAccount();
    
    await accountPage.verifyAccountDeleted();
});
