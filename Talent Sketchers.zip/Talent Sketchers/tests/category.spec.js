const {test} = require('@playwright/test')

test('Create Category', async({page})=>{

    await page.goto("https://super-rdp.honebi.online/");
    await page.locator("[name='username']").fill("admin@honeysys.com");
    await page.locator("[name='password']").fill("superrdp@7890");
    await page.locator("#kt_login_signin_submit").click();
    await page.getByText("Catalogue").click();


})