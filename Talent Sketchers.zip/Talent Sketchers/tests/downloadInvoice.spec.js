const { test, expect } = require('@playwright/test');
const { HomePage } = require('..pageobjects/HomePage');
const { CartPage } = require('..pageobjects/CartPage');
const { SignupPage } = require('../pageobjects/SignupPage');
const { AccountPage } = require('../pageobjects/AccountPage');


test('Download Invoice after purchase order', async ({page})=>{

    const homePage = new HomePage(page);
    const cartPage = new CartPage(page);
    const signupPage = new SignupPage(page);
    const accountPage = new AccountPage(page);
    
    homePage.goto();

    await homePage.isHomeIconVisible();

    await homePage.addProductToCart(0);

   
    await homePage.continueShopping();

    await homePage.addProductToCart(1);
    
    await homePage.continueShopping();

    await homePage.navigateToCart();

    await page.locator(".check_out").click();
    await page.locator("text='Register / Login'").click();

    await expect(page.locator('text="New User Signup!"')).toContainText('New User Signup!');

    await signupPage.fillSignupForm();

    await accountPage.verifyAccountCreated();

    await expect(accountPage.usernameText).toBeVisible();

    await homePage.navigateToCart();

    await page.locator(".check_out").click();
    let text = await page.locator("Address Details");
    await expect(text).toContainText('Address Details');

    await page.locator(".form-control").fill("Sample Text");

    await page.locator("text='Place Order'").click();
    
    await page.locator("[name='name_on_card']").fill('Sai Goli');

    await page.locator(".card-number").fill('6383783982982111');

    await page.locator(".card-cvc").fill('311');

    await page.locator(".card-expiry-month").fill('10');

    await page.locator(".card-expiry-year").fill('2025');

    await page.locator("submit").click();

    await page.locator(".check_out").click();

    await page.locator(".btn-primary").click();

    await accountPage.deleteAccount();
    
    await accountPage.verifyAccountDeleted();



})