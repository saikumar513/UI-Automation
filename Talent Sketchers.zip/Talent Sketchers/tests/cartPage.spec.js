const { test, expect } = require('@playwright/test');
const { HomePage } = require('..pageobjects/HomePage');
const { CartPage } = require('..pageobjects/CartPage');

test('Verify Subscription in Cart page', async ({ page }) => {
    const homePage = new HomePage(page);
    const cartPage = new CartPage(page);
    await homePage.goto();
    await page.screenshot({ path: 'Home.png' });
    await homePage.navigateToCart();
    await cartPage.footer.scrollIntoViewIfNeeded();
    await cartPage.verifySubscriptionText();
    await cartPage.subscribe('kiran13@gmail.com');
    await cartPage.verifySuccessMessage();

   
});
