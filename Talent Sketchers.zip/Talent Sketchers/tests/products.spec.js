const {test} = require('@playwright/test')

test('Create Global Product',async ({page})=>{

    await page.goto("https://super-rdp.honebi.online/");
    await page.locator("[name='username']").fill("admin@honeysys.com");
    await page.locator("[name='password']").fill("superrdp@7890");
    await page.locator("#kt_login_signin_submit").click();
    await page.locator("text=Products").click();
    await page.locator("text=Global Product").click();
    await page.locator("[class*='pull-right add_btndata btn']").click();
    await page.locator("[name=productName]").fill("Pan Masala");
    const dropDowns = page.locator("button.MuiAutocomplete-popupIndicator");
    await dropDowns.nth(0).click();
    await page.locator("text=BEVERAGES - COFFEE").click();
    await dropDowns.nth(1).click();
    await page.locator("text=FMCG Imported").click();
    await dropDowns.nth(2).click();
    await page.locator("text=3M STATIONERY").click();
    await page.locator("[name='shortDescription']").fill("New Product For Playwright");
    await page.locator("[name='itemCode']").fill("2348904245");
    await page.locator("text=Barcodes").fill("9378556789");
    const enter = page.locator("text=Barcodes");
    await enter.focus();
    await page.keyboard.press('Enter');
    await page.locator("[name='value']").fill("1");
    await dropDowns.nth(3).click();
    await page.locator("text=pcs").click();
    await page.locator("div.center_align ").first().click();
    await page.locator("div.footerHelndler").first().click();

});

