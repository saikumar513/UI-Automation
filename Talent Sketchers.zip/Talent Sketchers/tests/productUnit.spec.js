const {test} =require('@playwright/test')

test('Create Attribute', async ({page})=>{

    await page.goto("https://super-pkt.honebi.online/");
    await page.locator("[name='username']").fill("admin@honeysys.com");
    await page.locator("[name='password']").fill("super@789");
    await page.locator("#kt_login_signin_submit").click();
    await page.locator("text='Products'").click();
    await page.locator("text='Product Unit'").click();
    await page.locator("text='Create Product Unit'").click();
    await  page.locator("[name='unitName']").fill("Test");

    page.on('dialog',dialog => dialog.accept())

});