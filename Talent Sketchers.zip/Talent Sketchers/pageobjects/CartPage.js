class CartPage {
    constructor(page) {
        this.page = page;
        this.footer = page.locator('#footer');
        this.subscriptionText = page.locator('text="Subscription"');
        this.subscribeEmailInput = page.locator('#subscribe_email');
        this.subscribeButton = page.locator('#subscribe');
        this.successMessage = page.locator('text="You have been successfully subscribed!"');
        this.product1 = page.locator('#product-1');
        this.product2 = page.locator('#product-2');
        this.cartPrice = page.locator('.cart_price');
        this.cartQuantity = page.locator('.cart_quantity');
        this.cartTotal = page.locator('.cart_total');
    }

    async verifySubscriptionText() {
        await expect(this.subscriptionText).toBeVisible();
    }

    async subscribe(email) {
        await this.subscribeEmailInput.fill(email);
        await this.subscribeButton.click();
    }

    async verifySuccessMessage() {
        await expect(this.successMessage).toBeVisible();
    }

    async verifyProductInCart(productIndex) {
        await expect(this.page.locator(`#product-${productIndex}`)).toBeVisible();
    }

    async verifyCartDetails() {
        await expect(this.cartPrice).toBeVisible();
        await expect(this.cartQuantity).toBeVisible();
        await expect(this.cartTotal).toBeVisible();
    }
}

module.exports = { CartPage };