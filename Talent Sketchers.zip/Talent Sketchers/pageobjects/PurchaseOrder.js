class PurchaseOrder{

    constructor(page){

        this.page=page;
        this.checkOutButton = page.locator(".check_out");

    }



}