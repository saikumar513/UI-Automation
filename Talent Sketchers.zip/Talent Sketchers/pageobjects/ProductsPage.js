class ProductsPage {
    constructor(page) {
        this.page = page;
        this.allProductsHeader = page.locator('text="All Products"');
        this.searchInput = page.locator('#search_product');
        this.searchButton = page.locator('#submit_search');
        this.searchedProductsHeader = page.locator('text="Searched Products"');
    }

    async verifyAllProductsHeader() {
        await expect(this.allProductsHeader).toBeVisible();
    }

    async searchProduct(productName) {
        await this.searchInput.fill(productName);
        await this.searchButton.click();
    }

    async verifySearchedProductsHeader() {
        await expect(this.searchedProductsHeader).toBeVisible();
    }
}

module.exports = { ProductsPage };